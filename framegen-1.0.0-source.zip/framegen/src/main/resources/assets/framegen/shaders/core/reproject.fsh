#version 150

// Sampler0 = colour of the last real frame, Sampler1 = its depth buffer.
uniform sampler2D Sampler0;
uniform sampler2D Sampler1;

// All positions are expressed relative to the camera of the real (source) frame.
uniform mat4 SrcVP;     // projection * view of the source frame
uniform mat4 InvSrcVP;  // inverse of SrcVP
uniform mat4 InvDstVP;  // inverse of (projection * view) of the frame being generated
uniform vec3 Delta;     // generated camera position - source camera position
uniform vec3 Params;    // x = iterations, y = hole threshold

in vec2 texCoord;
out vec4 fragColor;

vec3 unproject(mat4 inv, vec2 ndcXY, float ndcZ) {
    vec4 p = inv * vec4(ndcXY, ndcZ, 1.0);
    return p.xyz / p.w;
}

// World position (source camera relative) of the surface stored at uv in the source frame.
vec3 sourcePos(vec2 uv) {
    float d = texture(Sampler1, uv).r;
    return unproject(InvSrcVP, uv * 2.0 - 1.0, d * 2.0 - 1.0);
}

// Where a point shows up in the source frame. Returns false if it is behind the source camera.
bool toSourceUV(vec3 q, out vec2 uv) {
    vec4 c = SrcVP * vec4(q, 1.0);
    if (c.w <= 0.0001) {
        uv = vec2(0.5);
        return false;
    }
    uv = c.xy / c.w * 0.5 + 0.5;
    return true;
}

void main() {
    // Ray of this pixel in the generated camera.
    vec2 ndc = texCoord * 2.0 - 1.0;
    vec3 rd = normalize(unproject(InvDstVP, ndc, 1.0));
    vec3 ro = Delta;

    // Background guess for disocclusions: what a very distant surface along the ray would show.
    vec2 uvFar;
    bool okFar = toSourceUV(ro + rd * 1024.0, uvFar);

    // Fixed point search for the surface point that is visible along the ray.
    float t = max(dot(sourcePos(texCoord) - ro, rd), 0.05);
    int n = int(Params.x);
    vec2 uv = texCoord;
    bool ok = true;
    for (int i = 0; i < n; i++) {
        ok = toSourceUV(ro + rd * t, uv);
        if (!ok) {
            break;
        }
        t = max(dot(sourcePos(clamp(uv, 0.0, 1.0)) - ro, rd), 0.05);
    }
    ok = toSourceUV(ro + rd * t, uv);

    vec2 cuv = clamp(uv, 0.0, 1.0);
    vec3 qs = sourcePos(cuv);
    vec3 onRay = ro + rd * dot(qs - ro, rd);
    float err = length(onRay - qs) / max(t, 1.0);

    bool hole = (!ok) || err > Params.y;
    vec2 sampleUV = (hole && okFar) ? clamp(uvFar, 0.0, 1.0) : cuv;

    fragColor = vec4(texture(Sampler0, sampleUV).rgb, 1.0);
}
