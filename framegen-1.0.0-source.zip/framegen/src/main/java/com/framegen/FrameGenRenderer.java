package com.framegen;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.GlUniform;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;
import org.lwjgl.opengl.GL30;

import java.lang.reflect.Method;

/**
 * Reprojection frame generation.
 *
 * Real frame:      vanilla/Sodium renders the world normally, we copy colour + depth of the main framebuffer.
 * Generated frame: the world render is cancelled and the saved colour/depth is re-projected with the
 *                  camera of the current frame (rotation + translation, depth aware). The hand and the GUI
 *                  are still drawn live by vanilla on top.
 */
public final class FrameGenRenderer {
    // GL objects holding the last real frame
    private static int fbo = 0;
    private static int colorTex = 0;
    private static int depthTex = 0;
    private static int width = 0;
    private static int height = 0;

    private static boolean valid = false;
    private static long captureNanos = 0L;
    private static ClientWorld capturedWorld = null;

    // camera of the last real frame
    private static final Matrix4f srcView = new Matrix4f();
    private static final Matrix4f srcProj = new Matrix4f();
    private static double srcX, srcY, srcZ;

    // camera of the real frame that is being rendered right now (promoted to src on capture)
    private static final Matrix4f pendingView = new Matrix4f();
    private static final Matrix4f pendingProj = new Matrix4f();
    private static double pendingX, pendingY, pendingZ;
    private static boolean pendingValid = false;

    private static int generatedSinceReal = 0;
    private static int errorChecks = 120;

    private static ShaderProgram shader;

    // Optional Iris detection (no compile time dependency)
    private static Object irisApi;
    private static Method irisInUse;

    static {
        try {
            Class<?> c = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
            irisApi = c.getMethod("getInstance").invoke(null);
            irisInUse = c.getMethod("isShaderPackInUse");
        } catch (Throwable ignored) {
            irisApi = null;
            irisInUse = null;
        }
    }

    private FrameGenRenderer() {
    }

    public static void setShader(ShaderProgram program) {
        shader = program;
    }

    public static void invalidate() {
        valid = false;
        pendingValid = false;
        generatedSinceReal = 0;
    }

    private static boolean shadersActive() {
        if (!FrameGenConfig.disableWithShaders || irisApi == null) {
            return false;
        }
        try {
            return (Boolean) irisInUse.invoke(irisApi);
        } catch (Throwable t) {
            return false;
        }
    }

    // ---------------------------------------------------------------- hooks called from the mixin

    /** Called at the start of WorldRenderer.render. Returns true if the world render must be skipped. */
    public static boolean onWorldRenderHead(Matrix4f view, Matrix4f proj, Vec3d cam) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (canGenerate(mc, cam)) {
            generatedSinceReal++;
            try {
                if (drawGenerated(view, proj, cam)) {
                    return true;
                }
            } catch (Throwable t) {
                FrameGenClient.LOGGER.error("Frame generation failed, disabling it", t);
                FrameGenConfig.enabled = false;
                invalidate();
                restoreState();
            }
        }

        // real frame
        generatedSinceReal = 0;
        pendingView.set(view);
        pendingProj.set(proj);
        pendingX = cam.x;
        pendingY = cam.y;
        pendingZ = cam.z;
        pendingValid = true;
        return false;
    }

    /** Called at the end of WorldRenderer.render of a real frame: save colour + depth. */
    public static void onWorldRenderReturn() {
        if (!pendingValid) {
            return;
        }
        pendingValid = false;

        if (!FrameGenConfig.enabled || shadersActive()) {
            valid = false;
            return;
        }

        MinecraftClient mc = MinecraftClient.getInstance();
        Framebuffer main = mc.getFramebuffer();
        int w = main.textureWidth;
        int h = main.textureHeight;
        if (!ensureTargets(w, h, main.fbo)) {
            valid = false;
            return;
        }

        boolean check = errorChecks > 0;
        if (check) {
            while (GL11.glGetError() != GL11.GL_NO_ERROR) {
                // drain old errors so we only see our own
            }
        }

        int prevRead = GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING);
        int prevDraw = GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING);
        GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, main.fbo);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, fbo);
        GL30.glBlitFramebuffer(0, 0, w, h, 0, 0, w, h,
                GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT, GL11.GL_NEAREST);
        GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, prevRead);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, prevDraw);

        if (check) {
            errorChecks--;
            int err = GL11.glGetError();
            if (err != GL11.GL_NO_ERROR) {
                FrameGenClient.LOGGER.error("Colour/depth copy failed (GL error 0x{}), disabling frame generation",
                        Integer.toHexString(err));
                FrameGenConfig.enabled = false;
                valid = false;
                return;
            }
        }

        srcView.set(pendingView);
        srcProj.set(pendingProj);
        srcX = pendingX;
        srcY = pendingY;
        srcZ = pendingZ;
        captureNanos = System.nanoTime();
        capturedWorld = mc.world;
        valid = true;
    }

    // ---------------------------------------------------------------- decision

    private static boolean canGenerate(MinecraftClient mc, Vec3d cam) {
        if (!FrameGenConfig.enabled || shader == null || !valid) {
            return false;
        }
        if (mc.world == null || mc.world != capturedWorld) {
            return false;
        }
        if (generatedSinceReal >= FrameGenConfig.multiplier - 1) {
            return false;
        }
        Framebuffer main = mc.getFramebuffer();
        if (main.textureWidth != width || main.textureHeight != height) {
            return false;
        }
        if ((System.nanoTime() - captureNanos) / 1_000_000L > FrameGenConfig.maxAgeMs) {
            return false;
        }
        double dx = cam.x - srcX;
        double dy = cam.y - srcY;
        double dz = cam.z - srcZ;
        double max = FrameGenConfig.maxMoveBlocks;
        if (dx * dx + dy * dy + dz * dz > max * max) {
            return false;
        }
        return !shadersActive();
    }

    // ---------------------------------------------------------------- drawing

    private static boolean drawGenerated(Matrix4f view, Matrix4f proj, Vec3d cam) {
        ShaderProgram program = shader;
        if (program == null) {
            return false;
        }

        Matrix4f srcVP = new Matrix4f(srcProj).mul(srcView);
        Matrix4f invSrcVP = new Matrix4f(srcVP).invert();
        Matrix4f invDstVP = new Matrix4f(proj).mul(view).invert();

        RenderSystem.setShader(() -> program);
        RenderSystem.setShaderTexture(0, colorTex);
        RenderSystem.setShaderTexture(1, depthTex);

        setMatrix(program, "SrcVP", srcVP);
        setMatrix(program, "InvSrcVP", invSrcVP);
        setMatrix(program, "InvDstVP", invDstVP);

        GlUniform delta = program.getUniform("Delta");
        if (delta != null) {
            delta.set((float) (cam.x - srcX), (float) (cam.y - srcY), (float) (cam.z - srcZ));
        }
        GlUniform params = program.getUniform("Params");
        if (params != null) {
            params.set((float) FrameGenConfig.iterations, FrameGenConfig.holeThreshold, 0.0f);
        }

        RenderSystem.disableBlend();
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);

        BufferBuilder bb = Tessellator.getInstance().getBuffer();
        bb.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION);
        bb.vertex(-1.0, -1.0, 0.0).next();
        bb.vertex(1.0, -1.0, 0.0).next();
        bb.vertex(1.0, 1.0, 0.0).next();
        bb.vertex(-1.0, 1.0, 0.0).next();
        BufferRenderer.drawWithGlobalProgram(bb.end());

        restoreState();
        return true;
    }

    private static void restoreState() {
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
    }

    private static void setMatrix(ShaderProgram program, String name, Matrix4f m) {
        GlUniform u = program.getUniform(name);
        if (u != null) {
            u.set(m);
        }
    }

    // ---------------------------------------------------------------- GL resources

    private static boolean ensureTargets(int w, int h, int mainFbo) {
        if (fbo != 0 && w == width && h == height) {
            return true;
        }
        destroyTargets();

        // Same texture formats as vanilla's main framebuffer so glBlitFramebuffer is legal for depth too.
        colorTex = createTexture(w, h, false);
        depthTex = createTexture(w, h, true);

        fbo = GL30.glGenFramebuffers();
        GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, fbo);
        GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, colorTex, 0);
        GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_DEPTH_ATTACHMENT, GL11.GL_TEXTURE_2D, depthTex, 0);
        int status = GL30.glCheckFramebufferStatus(GL30.GL_FRAMEBUFFER);
        GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, mainFbo);
        GlStateManager._bindTexture(0);

        if (status != GL30.GL_FRAMEBUFFER_COMPLETE) {
            FrameGenClient.LOGGER.error("FrameGen framebuffer incomplete (0x{}), disabling", Integer.toHexString(status));
            destroyTargets();
            FrameGenConfig.enabled = false;
            return false;
        }
        width = w;
        height = h;
        valid = false;
        return true;
    }

    private static int createTexture(int w, int h, boolean depth) {
        int id = GL11.glGenTextures();
        GlStateManager._bindTexture(id);
        int filter = depth ? GL11.GL_NEAREST : GL11.GL_LINEAR;
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, filter);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, filter);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL12.GL_CLAMP_TO_EDGE);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL12.GL_CLAMP_TO_EDGE);
        if (depth) {
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, 34892 /* GL_TEXTURE_COMPARE_MODE */, 0);
            GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_DEPTH_COMPONENT, w, h, 0,
                    GL11.GL_DEPTH_COMPONENT, GL11.GL_FLOAT, 0L);
        } else {
            GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA8, w, h, 0,
                    GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, 0L);
        }
        return id;
    }

    private static void destroyTargets() {
        if (fbo != 0) {
            GL30.glDeleteFramebuffers(fbo);
            fbo = 0;
        }
        if (colorTex != 0) {
            GL11.glDeleteTextures(colorTex);
            colorTex = 0;
        }
        if (depthTex != 0) {
            GL11.glDeleteTextures(depthTex);
            depthTex = 0;
        }
        width = 0;
        height = 0;
        valid = false;
    }
}
