package com.framegen;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Simple properties based config: .minecraft/config/framegen.properties */
public final class FrameGenConfig {
    /** Master switch (also toggled with F8). */
    public static boolean enabled = true;
    /** 2 = every second frame is generated, 3 = two of every three, 4 = three of every four. */
    public static int multiplier = 2;
    /** Reprojection search iterations in the shader (more = better parallax, slower). */
    public static int iterations = 4;
    /** Relative depth error above which a pixel is treated as a disocclusion hole. */
    public static float holeThreshold = 0.03f;
    /** If the last real frame is older than this, a real frame is forced. */
    public static int maxAgeMs = 120;
    /** If the camera moved further than this (blocks) since the last real frame, a real frame is forced. */
    public static float maxMoveBlocks = 3.0f;
    /** Do not generate frames while an Iris shader pack is active. */
    public static boolean disableWithShaders = true;

    private FrameGenConfig() {
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("framegen.properties");
    }

    public static void load() {
        Properties props = new Properties();
        Path p = path();
        if (Files.exists(p)) {
            try (InputStream in = Files.newInputStream(p)) {
                props.load(in);
            } catch (IOException e) {
                FrameGenClient.LOGGER.warn("Could not read {}: {}", p, e.toString());
            }
        }
        enabled = Boolean.parseBoolean(props.getProperty("enabled", String.valueOf(enabled)));
        multiplier = clamp(parseInt(props, "multiplier", multiplier), 2, 4);
        iterations = clamp(parseInt(props, "iterations", iterations), 1, 8);
        holeThreshold = clamp(parseFloat(props, "holeThreshold", holeThreshold), 0.001f, 1.0f);
        maxAgeMs = clamp(parseInt(props, "maxAgeMs", maxAgeMs), 10, 1000);
        maxMoveBlocks = clamp(parseFloat(props, "maxMoveBlocks", maxMoveBlocks), 0.1f, 64.0f);
        disableWithShaders = Boolean.parseBoolean(props.getProperty("disableWithShaders", String.valueOf(disableWithShaders)));
        save();
    }

    public static void save() {
        Properties props = new Properties();
        props.setProperty("enabled", String.valueOf(enabled));
        props.setProperty("multiplier", String.valueOf(multiplier));
        props.setProperty("iterations", String.valueOf(iterations));
        props.setProperty("holeThreshold", String.valueOf(holeThreshold));
        props.setProperty("maxAgeMs", String.valueOf(maxAgeMs));
        props.setProperty("maxMoveBlocks", String.valueOf(maxMoveBlocks));
        props.setProperty("disableWithShaders", String.valueOf(disableWithShaders));
        try (OutputStream out = Files.newOutputStream(path())) {
            props.store(out, "FrameGen config. multiplier 2-4, iterations 1-8");
        } catch (IOException e) {
            FrameGenClient.LOGGER.warn("Could not write config: {}", e.toString());
        }
    }

    private static int parseInt(Properties p, String key, int def) {
        try {
            return Integer.parseInt(p.getProperty(key, String.valueOf(def)).trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private static float parseFloat(Properties p, String key, float def) {
        try {
            return Float.parseFloat(p.getProperty(key, String.valueOf(def)).trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
