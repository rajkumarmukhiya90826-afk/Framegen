package com.framegen;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.CoreShaderRegistrationCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FrameGenClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("FrameGen");

    private static KeyBinding toggleKey;
    private static KeyBinding cycleKey;

    @Override
    public void onInitializeClient() {
        FrameGenConfig.load();

        CoreShaderRegistrationCallback.EVENT.register(context ->
                context.register(new Identifier("framegen", "reproject"), VertexFormats.POSITION,
                        FrameGenRenderer::setShader));

        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.framegen.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F8, "category.framegen"));
        cycleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.framegen.cycle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F9, "category.framegen"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                FrameGenConfig.enabled = !FrameGenConfig.enabled;
                FrameGenRenderer.invalidate();
                FrameGenConfig.save();
                message(client.player, FrameGenConfig.enabled
                        ? "FrameGen ON (x" + FrameGenConfig.multiplier + ")"
                        : "FrameGen OFF");
            }
            while (cycleKey.wasPressed()) {
                FrameGenConfig.multiplier = FrameGenConfig.multiplier >= 4 ? 2 : FrameGenConfig.multiplier + 1;
                FrameGenRenderer.invalidate();
                FrameGenConfig.save();
                message(client.player, "FrameGen multiplier x" + FrameGenConfig.multiplier);
            }
        });

        LOGGER.info("FrameGen loaded (F8 = toggle, F9 = change multiplier)");
    }

    private static void message(net.minecraft.client.network.ClientPlayerEntity player, String text) {
        if (player != null) {
            player.sendMessage(Text.literal(text), true);
        }
    }
}
