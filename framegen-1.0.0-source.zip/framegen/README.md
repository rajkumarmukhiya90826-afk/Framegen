# FrameGen (Fabric, Minecraft Java 1.20.1)

Reprojection based frame generation. Har `multiplier`-wa frame ke baad (default: har doosra frame)
world render **skip** hota hai aur pichle real frame ka colour + depth current camera ke hisaab se
re-project hota hai (rotation + translation, depth-aware). Hand aur GUI vanilla se live draw hote hain.

## Build

1. JDK 17 install karo.
2. Project folder me: `./gradlew build` (Windows: `gradlew.bat build`)
3. Jar milega: `build/libs/framegen-1.0.0.jar`

## Install

- Fabric Loader 0.15+ aur **Fabric API 0.92.2+1.20.1**
- `framegen-1.0.0.jar` ko `mods/` me daalo (Sodium ke saath chalega).

## Controls

- `F8`: FrameGen on/off
- `F9`: multiplier cycle (x2 -> x3 -> x4)
- Config: `config/framegen.properties` (multiplier, iterations, holeThreshold, maxAgeMs, maxMoveBlocks, disableWithShaders)

## Kya hai / kya nahi

- Ye DLSS-3 / FSR-3 jaisa motion-vector wala frame generation **nahi** hai (Minecraft ke OpenGL pipeline me motion vectors nahi hote).
- Camera rotation/movement ke liye achha kaam karta hai; chalte hue mobs/particles generated frames me half rate pe update hote hain.
- Disocclusion (kone/edges jo pehle dikhe nahi) me chhote artifacts aa sakte hain.
- Frame pacing: generated frame real frame ke turant baad aata hai, isliye FPS counter badhta hai par smoothness us hisaab se nahi badhti.
- Iris shader pack active ho to FrameGen apne aap band rehta hai (`disableWithShaders=false` se override, unsupported).
- Ye code is sandbox me compile/test nahi hua (Fabric maven access nahi tha). Pehli build me mapping/mixin error aaye to batao.
